<template>
    <div>
        404 找不到页面
    </div>
</template>

<script>
    export default {
        //name: "404"
    }
</script>

<style scoped>

</style>